<template>
    <div class="d-flex justify-content-center">
        <div class="spinner-grow text-secondary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
</template>

<script>
export default {
    props: ["size"],
};
</script>